<?php

/*
	Includes all application models.
	Relative route specifies only ../ as it is only meant to be used in:
		- Views
		- Controllers
		- Models
*/

include_once "../model/administrador.php";
include_once "../model/concurso.php";
include_once "../model/establecimiento.php";
include_once "../model/juradopopular.php";
include_once "../model/juradoprofesional.php";
include_once "../model/pincho.php";
include_once "../model/usuario.php";

?>