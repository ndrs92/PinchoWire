<?
include_once "../code/bd_manage.php";

//Script to add a bunch of data to de BD. To-do

?>